function pintar(ele, color) {
  ele.style.backgroundColor = color;
}

const ele = document.getElementById("ele1");
ele.addEventListener("click", () => {
  pintar(ele, "yellow");
});

const div = document.getElementById("key");

let color = "";
document.addEventListener("keydown", function (event) {
if (event.key === "a") {
  div.style.backgroundColor = "pink";
} else if (event.key === "s") {
  div.style.backgroundColor = "orange";
} else if (event.key === "d") {
  div.style.backgroundColor = "ltblue";
} else if (event.key === "q") {
  crearNuevoDiv("purple");
} else if (event.key === "w") {
  crearNuevoDiv("brown");
} else if (event.key === "e") {
  crearNuevoDiv("grey");
}
});

function crearNuevoDiv(color) {
const nuevoDiv = document.createElement("div");
nuevoDiv.style.width = "200px";
nuevoDiv.style.height = "200px";
nuevoDiv.style.backgroundColor = color;
document.body.appendChild(nuevoDiv);
}